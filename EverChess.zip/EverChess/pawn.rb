class Pawn
    attr_reader :color, :fwd_direction
    attr_accessor :pos

    def initialize(pos, color)
        @pos, @color = pos, color
        @fwd_direction = @color == :white ? -1 : 1
    end

    def valid_fwd_movement?(new_pos)
        new_pos[0] - self.pos[0] == self.fwd_direction && self.pos[1] == new_pos[1]
    end

     def valid_capture?(piece_to_capture)
        return false if piece_to_capture.nil?
        return false if piece_to_capture.color == self.color

        x_diff = piece_to_capture.pos[0] - self.pos[0]
        y_diff = piece_to_capture.pos[1] - self.pos[1]

        x_diff == self.fwd_direction && ([1, -1].any? {|el| el == x_diff})
    end


end