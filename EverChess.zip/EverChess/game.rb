require_relative 'board'

class Game

    def initialize
        @board = Board.new
        @current_color = :white
    end

    def play
        until @board.game_over?
            begin
                system("clear")
                @board.render
                puts "It's #{@current_color}'s turn"

                puts "Enter the position of the piece you'd like to move (ex. 0, 0)"
                move_from = sanitize_input(gets.chomp)

                piece = @board[move_from]
                if piece.nil?
                    raise ArgumentError.new("There's no piece there - try again!")
                elsif piece.color != @current_color
                    raise ArgumentError.new("That's not your piece - try again!")
                end

                puts "Enter the position you'd like to move to (ex. 0, 0)"
                move_to = sanitize_input(gets.chomp)

                if @board.valid_move?(piece, move_to)
                    @board.make_move(piece, move_to)
                    swap_turns
                end

            rescue ArgumentError => e
                puts e.message
                sleep(1)
                retry
            end
        end
        puts "Game over."
    end

    private

    def sanitize_input(input)
        result = input.split(',').map {|el| el.to_i}
        unless result.length == 2 && result.all? {|el| el.is_a?(Integer)}
            raise ArgumentError.new("That input was not formatted correctly - try again!")
        end
        result
    end

    def swap_turns
        @current_color = @current_color == :white ? :black : :white
    end

end

if $PROGRAM_NAME == __FILE__
  Game.new.play
end

