require_relative "pawn"
require "colorize"

class Board 

    def initialize
        @grid = Array.new(8) { Array.new(8) }
        fill_grid
    end

    def render
        print "   0  1  2  3  4  5  6  7 \n"
        @grid.each_with_index do |row, i|
            print "#{i} " 
            row.each do |piece|
                if piece
                    print " X ".colorize(piece.color)
                else 
                    print "   "
                end
            end
            puts
        end
    end

    def valid_move?(piece, new_pos)
        raise ArgumentError.new("That's not on the board") unless on_board?(new_pos)
    
        if can_capture_pieces?(piece.color) 
            piece_to_capture = self[new_pos]

            if piece.valid_capture?(piece_to_capture)
                true 
            else 
                raise ArgumentError.new("You have pieces to capture - try again!")
            end
        elsif !self[new_pos].nil?
            raise ArgumentError.new("Hey, there's a piece there! Try again.")
        elsif piece.valid_fwd_movement?(new_pos)
            true
        else   
            raise ArgumentError.new("That's not a valid move. Try again.") 
        end
    end

    def make_move(piece, move_to)
        old_pos = piece.pos
        self[move_to] = piece
        piece.pos = move_to
        self[old_pos] = nil
    end

    def game_over?

        black = get_pieces(:black)
        white = get_pieces(:white)

        # return true if any pieces are at end of board
        return true if black.any? {|piece| piece.pos[0] == 7}
        return true if white.any? {|piece| piece.pos[0] == 0}

        # return true if there are no more valid moves for any piece of either color
        return true unless has_remaining_moves?(black)
        return true unless has_remaining_moves?(white)

        false
    end

    def [](pos)
        x, y = pos 
        @grid[x][y]
    end

    def []=(pos, value)
        x, y = pos 
        @grid[x][y] = value
    end

    private

    def can_capture_pieces?(current_color)
        pieces = get_pieces(current_color)

        if current_color == :white
            diag_dirs = [[-1, 1], [-1, -1]]
        else
            diag_dirs = [[1, -1], [1, 1]]
        end

        pieces.any? do |piece|
            diag_dirs.any? do |dir|
                new_pos = [dir[0] + piece.pos[0], dir[1] + piece.pos[1]]
                return false unless on_board?(new_pos)
                # is a piece there & is the piece a different color
                self[new_pos] && self[new_pos].color != current_color
            end
        end

    end
    
    def on_board?(new_pos)
        new_pos.all? {|coord| coord >= 0 && coord < 8}
    end

    def fill_grid
        [:white, :black].each do |color|
            x = color == :white ? 6 : 1
            (0..7).each do |y|
                pos = [x, y]
                self[pos] = Pawn.new(pos, color)
            end
        end
    end

    def get_pieces(color)
        all_pieces = @grid.flatten
        return all_pieces.select {|piece| !piece.nil? && piece.color == color}
    end

    def has_remaining_moves?(pieces)
        @grid.each_with_index do |row, x|
            row.each_with_index do |_, y|
                pos = [x, y]
                return true if pieces.any? {|piece| valid_move_test?(piece, pos)}
            end
        end
        false 
    end

    # this is a copy of the valid_moves method, but does not raise exceptions 
    # the game_over? method shouldn't raise the same exceptions as the ones raised
    # when checking a player's move, but should still check for remaining valid moves
    def valid_move_test?(piece, pos)
        return false unless on_board?(pos)
    
        if can_capture_pieces?(piece.color) 
            piece_to_capture = self[pos]

            if piece.valid_capture?(piece_to_capture)
                true 
            else 
                false
            end

        elsif self[pos].nil? && piece.valid_fwd_movement?(pos)
            true
        else   
            false 
        end
    end
end
